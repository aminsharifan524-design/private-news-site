import { createClient } from "@/lib/supabase-server";
import { redirect } from "next/navigation";
import LogoutButton from "./ui-logout";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: news, error } = await supabase
    .from("News")
    .select("id,title,content,image_url,created_at")
    .eq("published", true)
    .order("created_at", { ascending: false });

  const isAdmin = user.app_metadata?.role === "admin";

  return (
    <>
      <header className="top">
        <strong>خبرگزاری خصوصی</strong>
        <div className="row">
          {isAdmin && <a href="/admin">مدیریت</a>}
          <LogoutButton />
        </div>
      </header>
      <main className="wrap">
        <h1>آخرین خبرها</h1>
        {error && <p className="error">خطا در دریافت خبرها؛ تنظیمات دسترسی دیتابیس باید بررسی شود.</p>}
        {(!news || news.length === 0) && <div className="card">هنوز خبری منتشر نشده است.</div>}
        {news?.map((item) => (
          <article className="card" key={item.id}>
            <h2>{item.title}</h2>
            {item.image_url && <img className="news-image" src={item.image_url} alt="تصویر خبر" />}
            <p style={{ whiteSpace: "pre-wrap", lineHeight: 2 }}>{item.content}</p>
            <small className="muted">
              {item.created_at ? new Date(item.created_at).toLocaleDateString("fa-IR") : ""}
            </small>
          </article>
        ))}
      </main>
    </>
  );
}
