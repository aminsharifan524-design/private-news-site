import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

export async function POST(req: Request) {
  const session = await createClient();
  const { data: { user } } = await session.auth.getUser();

  if (!user || user.app_metadata?.role !== "admin") {
    return NextResponse.json({ error: "دسترسی مجاز نیست." }, { status: 403 });
  }

  const { username, password } = await req.json();
  if (typeof username !== "string" || !/^[A-Za-z0-9_]{3,24}$/.test(username) ||
      typeof password !== "string" || password.length < 8) {
    return NextResponse.json({ error: "نام کاربری یا رمز عبور معتبر نیست." }, { status: 400 });
  }

  const admin = createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );

  const email = `${username.toLowerCase()}@login.private-news.invalid`;
  const { error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    app_metadata: { role: "user" }
  });

  if (error) {
    return NextResponse.json({
      error: error.message.toLowerCase().includes("already")
        ? "این نام کاربری قبلاً استفاده شده است."
        : "ساخت حساب انجام نشد."
    }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
