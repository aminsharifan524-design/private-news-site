import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function POST(req: Request) {
  const { secret, username, password } = await req.json();

  if (!process.env.BOOTSTRAP_SECRET || secret !== process.env.BOOTSTRAP_SECRET) {
    return NextResponse.json({ error: "کلید راه‌اندازی درست نیست." }, { status: 403 });
  }
  if (typeof username !== "string" || !/^[A-Za-z0-9_]{3,24}$/.test(username) ||
      typeof password !== "string" || password.length < 10) {
    return NextResponse.json({ error: "نام کاربری یا رمز عبور معتبر نیست." }, { status: 400 });
  }

  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );

  const email = `${username.toLowerCase()}@login.private-news.invalid`;
  const { error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    app_metadata: { role: "admin" }
  });

  if (error) {
    return NextResponse.json({ error: "ساخت مدیر انجام نشد؛ ممکن است نام کاربری تکراری باشد." }, { status: 400 });
  }
  return NextResponse.json({
    ok: true,
    message: "مدیر ساخته شد. حالا BOOTSTRAP_SECRET را از تنظیمات هاست حذف و دوباره Deploy کنید."
  });
}
