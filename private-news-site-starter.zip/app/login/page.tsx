 "use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase-browser";
import { useRouter } from "next/navigation";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const email = `${username.trim().toLowerCase()}@login.private-news.invalid`;
    const { error } = await createClient().auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      setError("نام کاربری یا رمز عبور اشتباه است.");
      return;
    }
    router.push("/");
    router.refresh();
  }

  return (
    <main className="wrap" style={{ maxWidth: 440, marginTop: 70 }}>
      <div className="card">
        <h1>ورود به خبرگزاری</h1>
        <p className="muted">برای مشاهده خبرها وارد حساب خود شوید.</p>
        <form onSubmit={submit}>
          <label>نام کاربری</label>
          <input className="field" autoComplete="username" value={username}
            onChange={e => setUsername(e.target.value)} required />
          <label>رمز عبور</label>
          <input className="field" type="password" autoComplete="current-password"
            value={password} onChange={e => setPassword(e.target.value)} required />
          <button className="button" disabled={busy}>{busy ? "در حال ورود..." : "ورود"}</button>
          {error && <p className="error">{error}</p>}
        </form>
      </div>
    </main>
  );
}
