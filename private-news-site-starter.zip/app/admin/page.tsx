import { createClient } from "@/lib/supabase-server";
import { redirect } from "next/navigation";
import AdminPanel from "./panel";

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (user.app_metadata?.role !== "admin") redirect("/");
  return (
    <>
      <header className="top">
        <strong>مدیریت خبرها و کاربران</strong>
        <a href="/">بازگشت به سایت</a>
      </header>
      <main className="wrap"><AdminPanel /></main>
    </>
  );
}
