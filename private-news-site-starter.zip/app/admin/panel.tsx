 "use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase-browser";

export default function AdminPanel() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  async function publish(e: React.FormEvent) {
    e.preventDefault();
    setMessage("");
    const { error } = await createClient().from("News").insert({
      title, content, image_url: image || null, published: true
    });
    setMessage(error ? "انتشار انجام نشد؛ دسترسی دیتابیس را بررسی کنید." : "خبر منتشر شد.");
    if (!error) { setTitle(""); setContent(""); setImage(""); }
  }

  async function addUser(e: React.FormEvent) {
    e.preventDefault();
    setMessage("");
    const response = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const result = await response.json();
    setMessage(response.ok ? "حساب کاربری ساخته شد." : (result.error || "ساخت حساب انجام نشد."));
    if (response.ok) { setUsername(""); setPassword(""); }
  }

  return (
    <>
      <section className="card">
        <h2>انتشار خبر</h2>
        <form onSubmit={publish}>
          <label>عنوان خبر</label>
          <input className="field" value={title} onChange={e => setTitle(e.target.value)} required />
          <label>متن خبر</label>
          <textarea className="field" rows={7} value={content}
            onChange={e => setContent(e.target.value)} required />
          <label>نشانی تصویر (اختیاری)</label>
          <input className="field" value={image} onChange={e => setImage(e.target.value)} />
          <button className="button">انتشار</button>
        </form>
      </section>
      <section className="card">
        <h2>ساخت حساب کاربری</h2>
        <form onSubmit={addUser}>
          <label>نام کاربری</label>
          <input className="field" value={username} onChange={e => setUsername(e.target.value)}
            pattern="[A-Za-z0-9_]{3,24}" title="۳ تا ۲۴ حرف انگلیسی، عدد یا زیرخط" required />
          <label>رمز عبور (حداقل ۸ نویسه)</label>
          <input className="field" type="password" minLength={8} value={password}
            onChange={e => setPassword(e.target.value)} required />
          <button className="button">ساخت حساب</button>
        </form>
        <p className="small muted">نام کاربری فقط شامل حروف انگلیسی، عدد و زیرخط باشد.</p>
      </section>
      {message && <p>{message}</p>}
    </>
  );
}
